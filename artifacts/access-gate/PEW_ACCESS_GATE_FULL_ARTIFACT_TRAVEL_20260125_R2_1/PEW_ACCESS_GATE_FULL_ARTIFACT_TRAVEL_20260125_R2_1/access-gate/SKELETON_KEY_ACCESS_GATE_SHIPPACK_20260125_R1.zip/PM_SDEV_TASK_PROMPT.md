📦 PM - sDEV | Access Gate Ingestion & Roadmap Tasks

Canonical prompt pointer for bot ingestion.
Authoritative source: chat prompt titled "📦 PM - sDEV — ACCESS GATE INGESTION & ROADMAP TASKS".

HARD RULES:
- No story rewrites
- No PART collapse
- Fail-closed
- No lesson loads until 100% validation
