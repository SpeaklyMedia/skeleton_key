SKELETON KEY — ACCESS GATE SHIPPACK
Version: 20260125_R1

Machine-readable shippack derived from canonical PDF (no edits).
Contains story index + annotated index + MCQ schema (answer keys TBD) + keying TODO.

LOCKS: fail-closed 19/19; no rewrites; visuals HERO + 1–2 inline; no filename reuse.
