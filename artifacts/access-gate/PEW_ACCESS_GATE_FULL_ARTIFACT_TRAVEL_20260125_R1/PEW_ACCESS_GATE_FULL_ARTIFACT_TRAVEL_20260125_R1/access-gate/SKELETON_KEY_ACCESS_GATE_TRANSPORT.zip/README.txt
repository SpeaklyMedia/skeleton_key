SKELETON KEY — ACCESS GATE
TRANSPORT ZIP (CANONICAL POINTER BUNDLE)

This zip is a transport bundle intended for PM - sDEV ingestion.
It references the canonical canvases created in ChatGPT and must be
used as an index + handoff artifact.

INCLUDED CANONICAL CANVASES (BY TITLE):
1. 🗝️ The Skeleton Key — Access Gate (Complete Story Summaries • Full Text)
2. 🗝️ The Skeleton Key — Access Gate (User-Facing Edition)
3. 🗝️ The Skeleton Key — Access Gate Story Index
4. 🗝️ The Skeleton Key — Access Gate Story Index (Annotated)
5. ACCESS_GATE_MCQ_SCHEMA
6. 📦 PM - sDEV | Access Gate Ingestion & Roadmap Tasks

NOTE:
These documents are LOCKED at source. This zip acts as a transport
manifest and ingestion pointer, not an editable content copy.

NEXT STEPS:
- PM - sDEV ingests via the task prompt
- MCQ implementation proceeds
- Visual briefs and lesson injection follow
