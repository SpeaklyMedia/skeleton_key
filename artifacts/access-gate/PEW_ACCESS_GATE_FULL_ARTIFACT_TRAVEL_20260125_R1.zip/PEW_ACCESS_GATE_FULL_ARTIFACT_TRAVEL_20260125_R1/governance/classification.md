# classification.md
project: Prompt Engineering Workbook
subsystem: Access Gate
placement: Workbook → Front-Matter → Access Gate → Prelude
classification_lock: true
notes:
  - Access Gate is pre-lesson gating, not a separate product.
